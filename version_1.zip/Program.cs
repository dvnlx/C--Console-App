﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csharp_console_app
{
    //here you can edit(in the namespace)
	internal class Program
	{
		static void Main(string[] args)
		{
            string hiworld;
            hiworld = "Hello World!";
			System.Console.WriteLine(hiworld);
		}
	}
}
