# C# Console App

- Requires .NET 6.0.101
